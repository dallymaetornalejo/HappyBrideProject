angular.module('app.controllers', [])
  
.controller('page5Ctrl', function($scope) {

})
   
.controller('homeCtrl', function($scope) {

})
   
.controller('cloudTabDefaultPageCtrl', function($scope) {

})
      
.controller('signUpCtrl', function($scope) {

})
 